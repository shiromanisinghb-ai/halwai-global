'use client'
import { Role } from '@/lib/types'

interface RoleSelectProps {
  onSelect: (role: Role) => void
}

export default function RoleSelect({ onSelect }: RoleSelectProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex flex-col">
      <header className="bg-white border-b border-gray-100 px-6 py-3">
        <span className="text-lg font-semibold text-saffron-600">Halwai <span className="text-maroon-600">Global</span></span>
      </header>
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="text-center mb-8">
          <span className="inline-block bg-amber-50 border border-amber-300 text-amber-800 text-xs px-4 py-1 rounded-full mb-4">
            Welcome to Halwai Global
          </span>
          <h1 className="text-3xl font-bold mb-2">
            Join as a <span className="text-saffron-600">customer</span> or <span className="text-maroon-600">halwai</span>
          </h1>
          <p className="text-gray-500 text-sm">Choose your account type to get started</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 w-full max-w-xl">
          <button
            onClick={() => onSelect('customer')}
            className="group text-left border-2 border-gray-100 hover:border-saffron-400 bg-white rounded-2xl p-6 transition-all duration-200 hover:shadow-md"
          >
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-800 font-bold text-lg mb-4">C</div>
            <h2 className="font-semibold text-base mb-1">I'm a Customer</h2>
            <p className="text-gray-500 text-sm mb-4">Book authentic Halwai for weddings, parties and events</p>
            <ul className="text-xs text-gray-400 space-y-1">
              <li>✓ Browse verified Halwai</li>
              <li>✓ AI-powered event planning</li>
              <li>✓ Secure payments and tracking</li>
              <li>✓ Rate and review vendors</li>
            </ul>
          </button>

          <button
            onClick={() => onSelect('halwai')}
            className="group text-left border-2 border-gray-100 hover:border-maroon-400 bg-white rounded-2xl p-6 transition-all duration-200 hover:shadow-md"
          >
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-900 font-bold text-lg mb-4">H</div>
            <h2 className="font-semibold text-base mb-1">I'm a Halwai</h2>
            <p className="text-gray-500 text-sm mb-4">Grow your catering business and reach customers globally</p>
            <ul className="text-xs text-gray-400 space-y-1">
              <li>✓ Professional profile</li>
              <li>✓ Manage menu and pricing</li>
              <li>✓ Analytics dashboard</li>
              <li>✓ Reach global customers</li>
            </ul>
          </button>
        </div>
      </div>
    </div>
  )
}
