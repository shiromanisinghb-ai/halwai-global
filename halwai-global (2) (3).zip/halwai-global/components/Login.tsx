'use client'
import { useState, useRef } from 'react'
import { Role, User } from '@/lib/types'

interface LoginProps {
  role: Role
  onBack: () => void
  onLogin: (user: User) => void
  showToast: (msg: string, type: 'success' | 'error') => void
}

export default function Login({ role, onBack, onLogin, showToast }: LoginProps) {
  const [step, setStep] = useState<'phone' | 'otp'>('phone')
  const [phone, setPhone] = useState('')
  const [otp, setOtp] = useState(['', '', '', '', '', ''])
  const [phoneErr, setPhoneErr] = useState('')
  const refs = useRef<(HTMLInputElement | null)[]>([])

  function handleSendOTP() {
    const digits = phone.replace(/\D/g, '')
    if (digits.length < 10) { setPhoneErr('Enter a valid 10-digit mobile number'); return }
    setPhoneErr('')
    setStep('otp')
    showToast('OTP sent! Demo code: 123456', 'success')
  }

  function handleOTPChange(val: string, idx: number) {
    if (!/^\d?$/.test(val)) return
    const next = [...otp]
    next[idx] = val
    setOtp(next)
    if (val && idx < 5) refs.current[idx + 1]?.focus()
  }

  function handleOTPKeyDown(e: React.KeyboardEvent, idx: number) {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) refs.current[idx - 1]?.focus()
  }

  function handleVerify() {
    const code = otp.join('')
    if (code.length !== 6) { showToast('Enter the 6-digit OTP', 'error'); return }
    if (code !== '123456') { showToast('Invalid OTP — use 123456 for demo', 'error'); return }
    showToast('Login successful!', 'success')
    setTimeout(() => {
      onLogin({
        name: role === 'customer' ? 'Priya Sharma' : 'Ramesh Gupta',
        email: role === 'customer' ? 'priya@example.com' : 'ramesh@guptasweets.com',
        phone,
        role,
        shopName: role === 'halwai' ? 'Gupta Sweets & Catering' : undefined,
      })
    }, 400)
  }

  function handleGoogleLogin() {
    showToast('Login successful!', 'success')
    setTimeout(() => {
      onLogin({
        name: role === 'customer' ? 'Priya Sharma' : 'Ramesh Gupta',
        email: role === 'customer' ? 'priya@example.com' : 'ramesh@guptasweets.com',
        phone: '+91 98765 43210',
        role,
        shopName: role === 'halwai' ? 'Gupta Sweets & Catering' : undefined,
      })
    }, 400)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-100 px-6 py-3">
        <span className="text-lg font-semibold text-saffron-600">Halwai <span className="text-maroon-600">Global</span></span>
      </header>
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="bg-white border border-gray-100 rounded-2xl p-7 w-full max-w-sm shadow-sm">
          <button onClick={onBack} className="text-xs text-gray-400 hover:text-gray-600 mb-4 flex items-center gap-1">
            ← Back to role selection
          </button>

          <span className="inline-block bg-amber-50 border border-amber-200 text-amber-800 text-xs px-3 py-1 rounded-full mb-3">
            {role === 'customer' ? 'Customer login' : 'Halwai login'}
          </span>
          <h2 className="text-xl font-semibold mb-1">Welcome back!</h2>
          <p className="text-sm text-gray-500 mb-5">Sign in to continue to your account</p>

          {step === 'phone' ? (
            <>
              <div className="mb-4">
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Mobile number</label>
                <input
                  type="tel"
                  className="input-field"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendOTP()}
                />
                {phoneErr && <p className="text-xs text-red-600 mt-1">{phoneErr}</p>}
              </div>
              <p className="text-xs text-gray-400 mb-4">We'll send you a one-time password</p>
              <button className="btn-primary w-full" onClick={handleSendOTP}>Send OTP</button>
            </>
          ) : (
            <>
              <p className="text-xs text-gray-500 mb-3">Code sent to <strong>{phone}</strong> <span className="text-saffron-600">(demo: 123456)</span></p>
              <div className="flex gap-2 justify-center mb-3">
                {otp.map((d, i) => (
                  <input
                    key={i}
                    ref={el => { refs.current[i] = el }}
                    className="w-10 h-10 border border-gray-200 rounded-lg text-center text-base font-semibold focus:outline-none focus:ring-2 focus:ring-saffron-400 bg-white"
                    maxLength={1}
                    value={d}
                    onChange={e => handleOTPChange(e.target.value, i)}
                    onKeyDown={e => handleOTPKeyDown(e, i)}
                  />
                ))}
              </div>
              <button className="text-xs text-saffron-600 underline mb-4 block" onClick={() => { setStep('phone'); setOtp(['','','','','','']) }}>
                Change phone number
              </button>
              <button className="btn-primary w-full mb-2" onClick={handleVerify}>Verify and login</button>
              <button className="btn-secondary w-full text-sm" onClick={handleSendOTP}>Resend OTP</button>
            </>
          )}

          <div className="flex items-center gap-2 my-4">
            <div className="flex-1 h-px bg-gray-100" />
            <span className="text-xs text-gray-400 uppercase">or</span>
            <div className="flex-1 h-px bg-gray-100" />
          </div>

          <button className="btn-secondary w-full flex items-center justify-center gap-2 text-sm" onClick={handleGoogleLogin}>
            <svg width="16" height="16" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continue with Google
          </button>

          <p className="text-center text-xs text-gray-400 mt-4">
            Don't have an account?{' '}
            <button className="text-saffron-600 underline" onClick={() => showToast('Registration coming soon!', 'success')}>Create one</button>
          </p>
        </div>
      </div>
    </div>
  )
}
