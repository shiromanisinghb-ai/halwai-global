'use client'
import { useEffect } from 'react'

interface ToastProps {
  message: string
  type: 'success' | 'error' | null
  onClose: () => void
}

export default function Toast({ message, type, onClose }: ToastProps) {
  useEffect(() => {
    if (type) {
      const t = setTimeout(onClose, 3000)
      return () => clearTimeout(t)
    }
  }, [type, message, onClose])

  if (!type) return null

  return (
    <div className={`fixed bottom-5 right-5 z-50 max-w-xs bg-white border rounded-lg px-4 py-3 text-sm shadow-lg transition-all duration-300 ${
      type === 'success' ? 'border-l-4 border-l-green-500 border-gray-100' : 'border-l-4 border-l-red-500 border-gray-100'
    }`}>
      <div className="flex items-center gap-2">
        <span>{type === 'success' ? '✓' : '✕'}</span>
        <span className="text-gray-800">{message}</span>
      </div>
    </div>
  )
}
