'use client'
import { useState } from 'react'
import { User, Order, INITIAL_ORDERS, MENU_ITEMS, REV_DATA, ORD_DATA, MONTHS, formatINR } from '@/lib/types'
import OrderCard from './OrderCard'
import BarChart from './BarChart'

interface Props {
  user: User
  onLogout: () => void
  showToast: (msg: string, type: 'success' | 'error') => void
}

type TabKey = 'overview' | 'orders' | 'menu' | 'analytics'

export default function HalwaiDash({ user, onLogout, showToast }: Props) {
  const [tab, setTab] = useState<TabKey>('overview')
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS)

  const tabs: { key: TabKey; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'orders', label: 'Orders' },
    { key: 'menu', label: 'Menu' },
    { key: 'analytics', label: 'Analytics' },
  ]

  const pendingCount = orders.filter(o => o.status === 'pending').length

  function acceptOrder(id: string) {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: 'confirmed' as const } : o))
    showToast('Order accepted!', 'success')
  }

  function rejectOrder(id: string) {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: 'rejected' as const } : o))
    showToast('Order rejected', 'error')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-100 px-6 py-3 flex justify-between items-center">
        <h1 className="text-base font-semibold"><span className="text-saffron-600">{user.shopName}</span> dashboard</h1>
        <button className="btn-secondary text-sm" onClick={onLogout}>Logout</button>
      </header>

      <div className="flex-1 p-4 max-w-5xl mx-auto w-full">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <div className="stat-card"><p className="text-xs text-gray-400 mb-1">Total revenue</p><p className="text-xl font-semibold">₹11.1L</p><p className="text-xs text-green-700 mt-1">+23% last month</p></div>
          <div className="stat-card"><p className="text-xs text-gray-400 mb-1">Total orders</p><p className="text-xl font-semibold">140</p><p className="text-xs text-green-700 mt-1">+12% last month</p></div>
          <div className="stat-card"><p className="text-xs text-gray-400 mb-1">Pending orders</p><p className="text-xl font-semibold">{pendingCount}</p><p className="text-xs text-amber-600 mt-1">Needs attention</p></div>
          <div className="stat-card"><p className="text-xs text-gray-400 mb-1">Rating</p><p className="text-xl font-semibold">4.8 ★</p><p className="text-xs text-gray-400 mt-1">156 reviews</p></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-4">
              {tabs.map(t => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex-1 py-1.5 text-xs rounded-lg font-medium transition-colors ${tab === t.key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {tab === 'overview' && (
              <>
                <div className="card mb-4">
                  <h3 className="font-medium text-sm mb-3">Revenue trend (₹L)</h3>
                  <BarChart data={REV_DATA} labels={MONTHS} color="#C2581A" prefix="₹" />
                </div>
                <div className="card">
                  <h3 className="font-medium text-sm mb-1">Recent orders</h3>
                  <p className="text-xs text-gray-400 mb-3">Latest booking requests</p>
                  {orders.slice(0, 3).map(o => (
                    <OrderCard key={o.id} order={o} showActions onAccept={acceptOrder} onReject={rejectOrder} />
                  ))}
                </div>
              </>
            )}

            {tab === 'orders' && (
              <div className="card">
                <h3 className="font-medium text-sm mb-1">All orders</h3>
                <p className="text-xs text-gray-400 mb-3">Manage booking requests</p>
                {orders.map(o => (
                  <OrderCard key={o.id} order={o} showActions onAccept={acceptOrder} onReject={rejectOrder} />
                ))}
              </div>
            )}

            {tab === 'menu' && (
              <div className="card">
                <h3 className="font-medium text-sm mb-1">Menu items</h3>
                <p className="text-xs text-gray-400 mb-3">Manage your products and pricing</p>
                {MENU_ITEMS.map(item => (
                  <div key={item.name} className="flex justify-between items-center border border-gray-100 rounded-xl p-3 mb-3">
                    <div>
                      <span className="font-medium text-sm">{item.name}</span>
                      <span className="badge-done ml-2">{item.category}</span>
                      <span className={`ml-1 ${item.available ? 'badge-success' : 'badge-rejected'}`}>
                        {item.available ? 'Available' : 'Out of stock'}
                      </span>
                      <p className="text-xs text-gray-400 mt-1">{formatINR(item.price)} {item.unit}</p>
                    </div>
                    <button className="btn-secondary text-xs py-1 px-3" onClick={() => showToast('Edit feature coming soon!', 'success')}>Edit</button>
                  </div>
                ))}
                <button className="btn-primary text-xs py-2 px-4 mt-1" onClick={() => showToast('Add menu item coming soon!', 'success')}>+ Add item</button>
              </div>
            )}

            {tab === 'analytics' && (
              <>
                <div className="card mb-4">
                  <h3 className="font-medium text-sm mb-3">Revenue analytics (₹L)</h3>
                  <BarChart data={REV_DATA} labels={MONTHS} color="#C2581A" />
                </div>
                <div className="card">
                  <h3 className="font-medium text-sm mb-3">Orders analytics</h3>
                  <BarChart data={ORD_DATA} labels={MONTHS} color="#8B1A1A" />
                </div>
              </>
            )}
          </div>

          <div>
            <div className="card text-center mb-4">
              <div className="w-14 h-14 rounded-full bg-red-100 text-red-900 flex items-center justify-center text-lg font-semibold mx-auto mb-3">
                {(user.shopName || 'GS').split(' ').slice(0, 2).map(w => w[0]).join('')}
              </div>
              <p className="font-semibold text-sm">{user.shopName}</p>
              <p className="text-xs text-gray-400 mt-1">{user.name} · Mumbai</p>
              <div className="mt-2 flex gap-1 justify-center flex-wrap">
                <span className="badge-success">Halwai partner</span>
                <span className="badge-done">✓ Verified</span>
              </div>
              <div className="mt-3 text-xs text-gray-400 text-left space-y-1.5">
                <div className="flex justify-between"><span>Experience</span><span>25 years</span></div>
                <div className="flex justify-between"><span>Location</span><span>Mumbai</span></div>
                <div className="flex justify-between"><span>Rating</span><span>4.8 ★</span></div>
              </div>
              <button className="btn-secondary w-full mt-3 text-xs" onClick={() => showToast('Edit profile coming soon!', 'success')}>Edit profile</button>
            </div>

            <div className="card">
              <h3 className="font-medium text-sm mb-3">Business status</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1.5 border-b border-gray-50">
                  <span className="text-gray-500">Availability</span><span className="badge-success">Open</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-gray-50">
                  <span className="text-gray-500">Menu items</span><span className="font-medium">4</span>
                </div>
                <div className="flex justify-between items-center py-1.5">
                  <span className="text-gray-500">Pending orders</span><span className="font-medium text-amber-600">{pendingCount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
