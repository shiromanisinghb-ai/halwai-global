'use client'
interface BarChartProps {
  data: number[]
  labels: string[]
  color?: string
  prefix?: string
}

export default function BarChart({ data, labels, color = '#C2581A', prefix = '' }: BarChartProps) {
  const max = Math.max(...data)
  return (
    <div>
      <div className="flex items-end gap-1.5 h-20 mb-1">
        {data.map((v, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
            <div
              className="w-full rounded-t transition-all duration-300"
              style={{ height: `${Math.round((v / max) * 72)}px`, background: color, opacity: 0.75 }}
              title={`${prefix}${v}`}
            />
          </div>
        ))}
      </div>
      <div className="flex gap-1.5">
        {labels.map(l => (
          <span key={l} className="flex-1 text-center text-xs text-gray-400">{l}</span>
        ))}
      </div>
    </div>
  )
}
