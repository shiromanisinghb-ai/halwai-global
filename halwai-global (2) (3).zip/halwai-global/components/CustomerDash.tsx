'use client'
import { useState } from 'react'
import { User } from '@/lib/types'
import OrderCard from './OrderCard'

const CUST_ORDERS = [
  { id: 'ORD-001', customer: 'Gupta Sweets & Catering', type: 'Wedding', date: '20 May 2026', guests: 500, status: 'confirmed' as const, amount: 150000, items: ['Gulab Jamun', 'Jalebi', 'Samosa'] },
  { id: 'ORD-002', customer: 'Mumbai Mithai House', type: 'Birthday', date: '25 Apr 2026', guests: 50, status: 'pending' as const, amount: 25000, items: ['Rasmalai', 'Kaju Katli'] },
  { id: 'ORD-003', customer: 'Royal Caterers', type: 'Corporate', date: '10 Mar 2026', guests: 200, status: 'completed' as const, amount: 80000, items: ['Samosa', 'Pakora', 'Chai'] },
]

interface Props {
  user: User
  onLogout: () => void
  showToast: (msg: string, type: 'success' | 'error') => void
}

type TabKey = 'overview' | 'orders' | 'favourites'

export default function CustomerDash({ user, onLogout, showToast }: Props) {
  const [tab, setTab] = useState<TabKey>('overview')

  const tabs: { key: TabKey; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'orders', label: 'My orders' },
    { key: 'favourites', label: 'Favourites' },
  ]

  const initials = user.name.split(' ').map(n => n[0]).join('')

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-100 px-6 py-3 flex justify-between items-center">
        <h1 className="text-base font-semibold">Welcome, <span className="text-saffron-600">{user.name.split(' ')[0]}</span>!</h1>
        <button className="btn-secondary text-sm" onClick={onLogout}>Logout</button>
      </header>

      <div className="flex-1 p-4 max-w-5xl mx-auto w-full">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          {[['Total bookings','12'],['Upcoming events','2'],['Favourites','5'],['Total spent','₹2.55L']].map(([l,v]) => (
            <div key={l} className="stat-card"><p className="text-xs text-gray-400 mb-1">{l}</p><p className="text-xl font-semibold">{v}</p></div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-4">
              {tabs.map(t => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex-1 py-1.5 text-xs rounded-lg font-medium transition-colors ${tab === t.key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {tab === 'overview' && (
              <>
                <div className="card border-l-4 border-l-saffron-600 mb-4 rounded-l-none rounded-r-xl">
                  <h3 className="font-medium text-sm mb-1">Become a Halwai partner</h3>
                  <p className="text-xs text-gray-400 mb-3">Share your culinary skills and grow your catering business globally</p>
                  <button className="btn-primary text-xs py-1.5 px-4" onClick={() => showToast('Redirecting to Halwai registration…', 'success')}>
                    Start your journey
                  </button>
                </div>
                <div className="card">
                  <h3 className="font-medium text-sm mb-1">Recent orders</h3>
                  <p className="text-xs text-gray-400 mb-3">Your latest bookings</p>
                  {CUST_ORDERS.map(o => (
                    <OrderCard key={o.id} order={o} onContact={() => showToast('Contact feature coming soon!', 'success')} onReview={() => showToast('Review submitted!', 'success')} />
                  ))}
                </div>
              </>
            )}

            {tab === 'orders' && (
              <div className="card">
                <h3 className="font-medium text-sm mb-1">All orders</h3>
                <p className="text-xs text-gray-400 mb-3">View and manage all your bookings</p>
                {CUST_ORDERS.map(o => (
                  <OrderCard key={o.id} order={o} onContact={() => showToast('Contact feature coming soon!', 'success')} onReview={() => showToast('Review submitted!', 'success')} />
                ))}
              </div>
            )}

            {tab === 'favourites' && (
              <div className="card">
                <h3 className="font-medium text-sm mb-1">Favourite Halwai</h3>
                <p className="text-xs text-gray-400 mb-3">Your saved vendors</p>
                {[
                  { nm: 'Gupta Sweets & Catering', loc: 'Mumbai, India', rating: '4.8', tag: 'Wedding catering', emoji: '🍬' },
                  { nm: 'Delhi Delights', loc: 'Delhi, India', rating: '4.9', tag: 'Traditional sweets', emoji: '🧁' },
                ].map(v => (
                  <div key={v.nm} className="flex gap-3 items-center border border-gray-100 rounded-xl p-3 mb-3">
                    <div className="w-11 h-11 rounded-lg bg-amber-50 flex items-center justify-center text-xl flex-shrink-0">{v.emoji}</div>
                    <div>
                      <p className="font-medium text-sm">{v.nm}</p>
                      <p className="text-xs text-gray-400">★ {v.rating} · {v.loc}</p>
                      <span className="badge-success mt-1 inline-block">{v.tag}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <div className="card text-center mb-4">
              <div className="w-14 h-14 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-lg font-semibold mx-auto mb-3">{initials}</div>
              <p className="font-semibold text-sm">{user.name}</p>
              <p className="text-xs text-gray-400 mt-1">{user.email}</p>
              <span className="badge-success mt-2 inline-block">Customer account</span>
              <button className="btn-secondary w-full mt-3 text-xs" onClick={() => showToast('Edit profile coming soon!', 'success')}>Edit profile</button>
            </div>
            <div className="card">
              <h3 className="font-medium text-sm mb-3">Quick actions</h3>
              {[
                ['📍', 'Find Halwai near me', 'Opening vendor discovery…'],
                ['📅', 'Plan an event', 'Opening AI event planner…'],
                ['💬', 'Support chat', 'Support chat coming soon!'],
                ['🔔', 'Notifications', 'No new notifications'],
              ].map(([icon, label, msg]) => (
                <button key={label} className="flex items-center gap-2.5 w-full border border-gray-100 rounded-lg px-3 py-2 text-xs text-left hover:bg-gray-50 mb-2" onClick={() => showToast(msg, 'success')}>
                  <span className="text-base">{icon}</span>{label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
