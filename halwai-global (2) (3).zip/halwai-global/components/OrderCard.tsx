'use client'
import { Order, formatINR, OrderStatus } from '@/lib/types'

const badgeClass: Record<OrderStatus, string> = {
  pending: 'badge-pending',
  confirmed: 'badge-success',
  completed: 'badge-done',
  rejected: 'badge-rejected',
}

interface OrderCardProps {
  order: Order
  showActions?: boolean
  onAccept?: (id: string) => void
  onReject?: (id: string) => void
  onContact?: () => void
  onReview?: () => void
}

export default function OrderCard({ order, showActions, onAccept, onReject, onContact, onReview }: OrderCardProps) {
  return (
    <div className="border border-gray-100 rounded-xl p-3 mb-3">
      <div className="flex justify-between items-start mb-1.5">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-sm">{order.customer}</span>
          <span className={badgeClass[order.status]}>{order.status}</span>
        </div>
        <span className="font-semibold text-sm">{formatINR(order.amount)}</span>
      </div>
      <p className="text-xs text-gray-500 mb-2">{order.id} · {order.type} · {order.guests} guests · {order.date}</p>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {order.items.map(item => (
          <span key={item} className="bg-amber-50 text-amber-800 text-xs px-2 py-0.5 rounded-full">{item}</span>
        ))}
      </div>
      <div className="flex gap-2 flex-wrap">
        <button className="btn-secondary text-xs py-1 px-3">View details</button>
        {showActions && order.status === 'pending' && onAccept && onReject && (
          <>
            <button className="btn-success" onClick={() => onAccept(order.id)}>✓ Accept</button>
            <button className="btn-danger" onClick={() => onReject(order.id)}>✕ Reject</button>
          </>
        )}
        {!showActions && order.status === 'confirmed' && onContact && (
          <button className="btn-secondary text-xs py-1 px-3" onClick={onContact}>Contact Halwai</button>
        )}
        {!showActions && order.status === 'completed' && onReview && (
          <button className="btn-secondary text-xs py-1 px-3" onClick={onReview}>Leave review</button>
        )}
      </div>
    </div>
  )
}
