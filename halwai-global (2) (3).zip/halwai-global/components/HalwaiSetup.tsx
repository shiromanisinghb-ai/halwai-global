'use client'
import { useState } from 'react'
import { User } from '@/lib/types'

interface SetupProps {
  user: User
  onComplete: (shopName: string) => void
  onSkip: () => void
  showToast: (msg: string, type: 'success' | 'error') => void
}

export default function HalwaiSetup({ user, onComplete, onSkip, showToast }: SetupProps) {
  const [step, setStep] = useState(1)
  const [shop, setShop] = useState('')
  const [exp, setExp] = useState('')
  const [desc, setDesc] = useState('')
  const [addr, setAddr] = useState('')
  const [city, setCity] = useState('')
  const [state, setState] = useState('')
  const [country, setCountry] = useState('India')
  const [specs, setSpecs] = useState<string[]>([])
  const [specInput, setSpecInput] = useState('')

  function next1() {
    if (shop.trim().length < 3) { showToast('Shop name needs at least 3 characters', 'error'); return }
    if (!exp || isNaN(Number(exp)) || Number(exp) < 0) { showToast('Enter valid years of experience', 'error'); return }
    if (desc.trim().length < 20) { showToast('Description needs at least 20 characters', 'error'); return }
    setStep(2)
  }

  function next2() {
    if (!addr.trim() || !city.trim() || !state.trim()) { showToast('Fill all location fields', 'error'); return }
    setStep(3)
  }

  function addSpec() {
    const v = specInput.trim()
    if (!v) return
    if (specs.includes(v)) { showToast('Already added', 'error'); return }
    setSpecs([...specs, v])
    setSpecInput('')
  }

  function submit() {
    if (specs.length === 0) { showToast('Add at least one specialty', 'error'); return }
    showToast('Profile created successfully!', 'success')
    setTimeout(() => onComplete(shop.trim()), 500)
  }

  const steps = [1, 2, 3]

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-100 px-6 py-3 flex justify-between items-center">
        <span className="text-lg font-semibold text-saffron-600">Halwai <span className="text-maroon-600">Global</span></span>
        <button className="btn-secondary text-sm" onClick={onSkip}>Skip for now</button>
      </header>
      <div className="flex-1 flex items-start justify-center p-6 pt-10">
        <div className="bg-white border border-gray-100 rounded-2xl p-7 w-full max-w-md shadow-sm">
          <div className="text-center mb-5">
            <h2 className="text-lg font-semibold mb-1">Setup your Halwai profile</h2>
            <p className="text-sm text-gray-400">Let's set up your catering business</p>
          </div>

          <div className="flex gap-1.5 mb-6">
            {steps.map(s => (
              <div key={s} className={`flex-1 h-1 rounded-full transition-colors duration-300 ${s <= step ? 'bg-saffron-600' : 'bg-gray-100'}`} />
            ))}
          </div>

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Shop / business name *</label>
                <input className="input-field" placeholder="e.g., Gupta Sweets & Catering" value={shop} onChange={e => setShop(e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Years of experience *</label>
                <input className="input-field" type="number" min="0" max="80" placeholder="e.g., 15" value={exp} onChange={e => setExp(e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Business description *</label>
                <textarea
                  className="input-field resize-none"
                  rows={3}
                  placeholder="Tell customers about your business…"
                  value={desc}
                  onChange={e => setDesc(e.target.value)}
                />
                <p className="text-xs text-gray-400 mt-1">
                  {desc.length < 20 ? `At least 20 characters (${desc.length}/20)` : 'Looks good!'}
                </p>
              </div>
              <button className="btn-primary w-full" onClick={next1}>Continue →</button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Street address *</label>
                <input className="input-field" placeholder="e.g., 123 Main Street, Sector 5" value={addr} onChange={e => setAddr(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">City *</label>
                  <input className="input-field" placeholder="Mumbai" value={city} onChange={e => setCity(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">State *</label>
                  <input className="input-field" placeholder="Maharashtra" value={state} onChange={e => setState(e.target.value)} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Country</label>
                <select className="input-field" value={country} onChange={e => setCountry(e.target.value)}>
                  {['India', 'USA', 'UAE', 'UK', 'Canada'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary flex-none" onClick={() => setStep(1)}>Back</button>
                <button className="btn-primary flex-1" onClick={next2}>Continue →</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Specialties *</label>
                <div className="flex gap-2 mb-2">
                  <input
                    className="input-field flex-1"
                    placeholder="e.g., Wedding catering"
                    value={specInput}
                    onChange={e => setSpecInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addSpec() } }}
                  />
                  <button className="btn-primary px-3" onClick={addSpec}>Add</button>
                </div>
                {specs.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {specs.map((s, i) => (
                      <span key={i} className="inline-flex items-center gap-1 bg-amber-50 border border-amber-200 text-amber-800 text-xs px-2.5 py-1 rounded-full">
                        {s}
                        <button onClick={() => setSpecs(specs.filter((_, j) => j !== i))} className="text-amber-600 hover:text-amber-900 leading-none">×</button>
                      </span>
                    ))}
                  </div>
                )}
                <p className="text-xs text-gray-400">Press Enter or click Add</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-400">
                After setup you can add menu items, set availability and start receiving orders.
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary flex-none" onClick={() => setStep(2)}>Back</button>
                <button className="btn-primary flex-1" onClick={submit}>Complete setup</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
