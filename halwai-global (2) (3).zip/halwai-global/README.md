# Halwai Global 🍬

Authentic Indian catering platform — connect customers with verified Halwai professionals for weddings, parties, and events.

## Tech Stack
- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **Vercel** (deployment)

## Features
- Role-based auth (Customer / Halwai)
- OTP login flow (demo code: `123456`)
- Customer dashboard — bookings, favourites, quick actions
- Halwai dashboard — order management (accept/reject), menu, analytics
- Halwai onboarding wizard (3-step profile setup)

## Local Development

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Deploy to Vercel

### Option 1 — Vercel CLI (fastest)
```bash
npm install -g vercel
vercel
```
Follow the prompts. Your app will be live in ~60 seconds.

### Option 2 — GitHub + Vercel Dashboard
1. Push this repo to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your GitHub repo
4. Click **Deploy** — Vercel auto-detects Next.js

### Option 3 — Deploy Button
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

## Project Structure
```
halwai-global/
├── app/
│   ├── layout.tsx        # Root layout + metadata
│   ├── page.tsx          # Main page (screen router)
│   └── globals.css       # Tailwind + custom classes
├── components/
│   ├── RoleSelect.tsx    # Role selection screen
│   ├── Login.tsx         # Phone + OTP login
│   ├── HalwaiSetup.tsx   # 3-step onboarding wizard
│   ├── CustomerDash.tsx  # Customer dashboard
│   ├── HalwaiDash.tsx    # Halwai dashboard
│   ├── OrderCard.tsx     # Reusable order card
│   ├── BarChart.tsx      # Revenue/orders chart
│   └── Toast.tsx         # Notification toast
├── lib/
│   └── types.ts          # Types, data, utilities
├── tailwind.config.js
├── next.config.js
└── vercel.json
```

## Demo Credentials
- Any 10-digit phone number
- OTP: `123456`
