export type Role = 'customer' | 'halwai'

export type OrderStatus = 'pending' | 'confirmed' | 'completed' | 'rejected'

export interface Order {
  id: string
  customer: string
  type: string
  date: string
  guests: number
  status: OrderStatus
  amount: number
  items: string[]
}

export interface MenuItem {
  name: string
  category: string
  price: number
  unit: string
  available: boolean
}

export interface User {
  name: string
  email: string
  phone: string
  role: Role
  shopName?: string
}

export const INITIAL_ORDERS: Order[] = [
  { id: 'ORD-001', customer: 'Rajesh Kumar', type: 'Wedding', date: '20 May 2026', guests: 500, status: 'pending', amount: 150000, items: ['Gulab Jamun', 'Jalebi', 'Samosa', 'Paneer Tikka'] },
  { id: 'ORD-002', customer: 'Priya Sharma', type: 'Birthday', date: '25 Apr 2026', guests: 50, status: 'confirmed', amount: 25000, items: ['Rasmalai', 'Kaju Katli', 'Ladoo'] },
  { id: 'ORD-003', customer: 'Tech Corp Ltd', type: 'Corporate', date: '15 Jun 2026', guests: 200, status: 'pending', amount: 80000, items: ['Samosa', 'Pakora', 'Chai'] },
]

export const MENU_ITEMS: MenuItem[] = [
  { name: 'Gulab Jamun', category: 'Sweets', price: 250, unit: 'per kg', available: true },
  { name: 'Jalebi', category: 'Sweets', price: 200, unit: 'per kg', available: true },
  { name: 'Wedding Package', category: 'Catering', price: 300, unit: 'per person', available: true },
  { name: 'Samosa', category: 'Snacks', price: 150, unit: 'per dozen', available: false },
]

export const REV_DATA = [120, 150, 180, 220, 190, 250]
export const ORD_DATA = [15, 18, 22, 28, 25, 32]
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']

export function formatINR(amount: number): string {
  return '₹' + amount.toLocaleString('en-IN')
}
