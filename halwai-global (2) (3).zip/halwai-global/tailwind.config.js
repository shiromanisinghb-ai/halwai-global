/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        saffron: {
          50: '#FFF8F0',
          100: '#FEE8D0',
          200: '#FDC89A',
          400: '#E8711A',
          600: '#C2581A',
          800: '#8B3A0E',
        },
        maroon: {
          50: '#FFF0F0',
          400: '#C0392B',
          600: '#8B1A1A',
          800: '#5C1010',
        },
      },
      fontFamily: {
        display: ['Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
