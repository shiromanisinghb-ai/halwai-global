'use client'
import { useState, useCallback } from 'react'
import { Role, User } from '@/lib/types'
import RoleSelect from '@/components/RoleSelect'
import Login from '@/components/Login'
import HalwaiSetup from '@/components/HalwaiSetup'
import CustomerDash from '@/components/CustomerDash'
import HalwaiDash from '@/components/HalwaiDash'
import Toast from '@/components/Toast'

type Screen = 'role' | 'login' | 'setup' | 'customer-dash' | 'halwai-dash'

export default function Home() {
  const [screen, setScreen] = useState<Screen>('role')
  const [role, setRole] = useState<Role>('customer')
  const [user, setUser] = useState<User | null>(null)
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null)

  const showToast = useCallback((msg: string, type: 'success' | 'error') => {
    setToast({ msg, type })
  }, [])

  function handleRoleSelect(r: Role) {
    setRole(r)
    setScreen('login')
  }

  function handleLogin(u: User) {
    setUser(u)
    if (u.role === 'halwai') setScreen('setup')
    else setScreen('customer-dash')
  }

  function handleSetupComplete(shopName: string) {
    setUser(prev => prev ? { ...prev, shopName } : prev)
    setScreen('halwai-dash')
  }

  function handleSkipSetup() {
    setScreen('halwai-dash')
  }

  function handleLogout() {
    setUser(null)
    setScreen('role')
    showToast('Logged out successfully', 'success')
  }

  return (
    <>
      {screen === 'role' && <RoleSelect onSelect={handleRoleSelect} />}
      {screen === 'login' && <Login role={role} onBack={() => setScreen('role')} onLogin={handleLogin} showToast={showToast} />}
      {screen === 'setup' && user && <HalwaiSetup user={user} onComplete={handleSetupComplete} onSkip={handleSkipSetup} showToast={showToast} />}
      {screen === 'customer-dash' && user && <CustomerDash user={user} onLogout={handleLogout} showToast={showToast} />}
      {screen === 'halwai-dash' && user && <HalwaiDash user={user} onLogout={handleLogout} showToast={showToast} />}

      <Toast
        message={toast?.msg || ''}
        type={toast?.type || null}
        onClose={() => setToast(null)}
      />
    </>
  )
}
