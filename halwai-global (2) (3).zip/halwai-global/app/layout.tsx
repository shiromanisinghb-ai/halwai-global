import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Halwai Global — Authentic Indian Catering',
  description: 'Book authentic Halwai for weddings, parties and events. Connect with verified catering professionals across India and the globe.',
  keywords: 'halwai, catering, wedding catering, indian sweets, event catering',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  )
}
